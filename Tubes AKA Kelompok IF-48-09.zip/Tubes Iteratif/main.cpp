#include "iteratif.h"
#include <chrono>

using namespace std;

int main() {
    int n1;

    cout << "-------------------------------------" << endl;
    cout << "PENGECEK BILANGAN SEMPURNA (ITERATIF)" << endl;
    cout << "-------------------------------------" << endl;
    cout << "Masukkan bilangan sebagai batas atas (Domain >= 1): ";

    n1 = 8128; // Bilangan yang dipilih

    // Mulai timing
    auto start = std::chrono::high_resolution_clock::now();

    if (bilanganSempurna(n1, n1/2) == n1) {
        cout << n1 << " adalah bilangan sempurna!" << endl;
    } else {
        cout << n1 << " BUKAN bilangan sempurna!" << endl;
    }

    // Akhiri timing
    auto stop = std::chrono::high_resolution_clock::now();
    auto duration =
        std::chrono::duration_cast<std::chrono::microseconds>(stop - start);

    cout << "Waktu eksekusi: " << duration.count()
         << " microseconds" << endl;

    return 0;
}
