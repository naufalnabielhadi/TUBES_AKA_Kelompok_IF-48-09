#include "iteratif.h"

int bilanganSempurna(int n1,int n2){

    int sum = 0;
    int i;
    for(i=n2;i>=1;i--){
        if(n1%i==0){
            sum += i;
        }
    }
    return sum;
}
