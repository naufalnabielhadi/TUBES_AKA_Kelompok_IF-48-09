#include "rekursif.h"
#include <iostream>
#include <chrono>

using namespace std;

int main()
{
    int n1;
    cout << "-------------------------------------" << endl;
    cout << "PENGECEK BILANGAN SEMPURNA (REKURSIF)" << endl;
    cout << "-------------------------------------" << endl;
    cout << "Masukkan bilangan sebagai batas atas (Domain >= 1): ";

    n1 = 8128;

    auto startTime = std::chrono::high_resolution_clock::now();

    if (bilanganSempurna(n1, n1/2) == n1) {
        cout << n1 << " adalah bilangan sempurna!" << endl;
    } else {
        cout << n1 << " BUKAN bilangan sempurna!" << endl;
    }

    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration =
        std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime);

    cout << "Waktu eksekusi: " << duration.count()
         << " microseconds" << endl;

    return 0;
}
