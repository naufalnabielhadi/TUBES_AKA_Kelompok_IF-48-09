#include "rekursif.h"

int bilanganSempurna(int n1,int n2){

    if(n2 == 0){
        return 0;
    } else if (n2 == 1){
        return n2;
    } else if(n1%n2 == 0){
        return n2 + bilanganSempurna(n1,n2-1);
    } else {
        return bilanganSempurna(n1,n2-1);
    }
}
