#ifndef REKURSIF_H_INCLUDED
#define REKURSIF_H_INCLUDED
#include <iostream>
using namespace std;

int bilanganSempurna(int n1, int n2);

#endif // REKURSIF_H_INCLUDED
